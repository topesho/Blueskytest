package stepsDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import pageObjects.Test1Page;
import utilities.Hooks;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class TestSteps {

    WebDriver driver;

    Test1Page test1Page;

    public TestSteps(Hooks hooks) {
        driver = hooks.getDriver();
        test1Page = new Test1Page(hooks);
    }

    @Given("a user navigate to {string}")
    public void aUserNavigateTo(String url) {
        test1Page.navigateToWebsite(url);
    }

    @And("a user click on run button")
    public void aUserClickOnRunButton() {
        test1Page.clickRunButton();
    }

    @Then("the text {string} is displayed in the Output Window")
    public void theTextIsDisplayedInTheOutputWindow(String windowOutput) {
        assertThat(test1Page.windowOutputIsDisplayed(), equalTo(true));
        assertThat(test1Page.getWindowOutputText(), equalToIgnoringCase(windowOutput));
    }
}