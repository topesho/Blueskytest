package utilities;

import cucumber.runtime.Timeout;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Hooks {
    public WebDriver driver;

    @Before
    public WebDriver getDriver() {
        if (driver == null){
            System.setProperty("webdriver.chrome.driver","C:\\SKYTEST\\src\\test\\resources\\chromeDriver\\chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        }
        return driver;
    }

    @After
    public void tearDown(){
        driver.close();
        driver.quit();
    }
}
