package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utilities.Hooks;

public class Test1Page {
    public WebDriver driver;

    By runButton = By.id("run-button");


    By windowOutput = By.cssSelector("div[id='output']");



    public Test1Page(Hooks hooks){
        driver = hooks.getDriver();
    }

    public void navigateToWebsite(String url)
    {
      driver.navigate().to(url);

    }

    public void clickRunButton()
    {
        driver.findElement(runButton).click();

    }


    public Boolean windowOutputIsDisplayed()
    {
       return driver.findElement(windowOutput).isDisplayed();

    }

    public String getWindowOutputText()
    {
        return driver.findElement(windowOutput).getText();

    }

}
